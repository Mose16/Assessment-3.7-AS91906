# Assessment-3.7-AS91906

Hire a Bro

Goal for this program:
- Create a good looking UI
- Run the website throgh bottle and python
- Manage sales and stocking items.
