# Assessment-3.7-AS91906

Hire a Bro

Goal for this program:
- Create a good looking UI
- Run the website throgh bottle and python
- Manage sales and stocking items.

Ver-2
  Asthetics for home page, python routing for Css, script and images.
  Products page created, nothing in it.
  
Ver-3
  Product page created with basic card function, simple class and array functions in python file to manage the bro cards.
  Images uploaded
  
Ver-4
  Product page finished with purchase button functioning, purchase and purchase_success pages created managing the purchase proccess of     the products with changes to the python file adding functionality. Planning document for this version.
  
Ver-5
  Create a return system to restock the items, requires name and last name of the booker.

Ver-6
  Create a application form to add new stock to products.

Ver-7
  Errors found and fixed. Final changes and final planning document
